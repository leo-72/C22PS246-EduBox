package com.example.edubox.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.edubox.R

class DetailMateriActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}